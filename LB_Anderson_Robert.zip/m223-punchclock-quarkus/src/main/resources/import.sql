INSERT INTO CATEGORY(title) VALUES ('Adminstratives');
INSERT INTO CATEGORY(title) VALUES ('Planung');
INSERT INTO CATEGORY(title) VALUES ('Implementierung');
INSERT INTO CATEGORY(title) VALUES ('Testen');
INSERT INTO CATEGORY(title) VALUES ('Ferien');

INSERT INTO LOGTYPE(typeName) VALUES ('login');

INSERT INTO USER (username, password) VALUES ('zli', 'secret');